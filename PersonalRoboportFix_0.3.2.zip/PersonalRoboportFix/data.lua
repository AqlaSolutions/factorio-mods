--entity
require("prototypes.entities")

--items
require("prototypes.items")

--recipies
require("prototypes.recipes")

--tech
require("prototypes.tech")

--equipment 
require("prototypes.equipment")