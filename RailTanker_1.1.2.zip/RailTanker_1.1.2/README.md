# RailTanker
Oil Tanker for Factorio
