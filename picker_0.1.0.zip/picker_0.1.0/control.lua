require "defines"

script.on_event(defines.events.on_tick, function(event)
  p = game.players[1]
  if p.cursor_stack.valid_for_read then
    if p.cursor_stack.name == "tool-picker" then
      pick, adv, pname = true, false, "tool-picker"
    elseif p.cursor_stack.name == "tool-picker-advanced" then
      pick, adv, pname = true, true, "tool-picker-advanced"
    else
      pick = false
    end
    if pick then
      -- Return the picker tool to inventory:
      qb = p.get_inventory(defines.inventory.player_quickbar)
      if qb.can_insert({name = pname, count = p.cursor_stack.count}) then
        qb.insert({name = pname, count = p.cursor_stack.count})
      else
        p.insert({name = pname, count = p.cursor_stack.count})
      end
      p.cursor_stack.clear()
      if p.selected then
        if adv or p.can_reach_entity(p.selected) then
          item = p.selected.name
          ip = game.item_prototypes[item]
          if ip then  -- If the item has a prototype, then it's something we can pick up.
            n = math.min(p.get_item_count(item), ip.stack_size)
            if n > 0 then
              -- Put items in the cursor stack:
              p.cursor_stack.set_stack({name=item, count=n})
              -- Remove an equal number from the main inventory:
              p.remove_item({name = item, count = n})
            else
              p.print("No "..item.." in inventory.")
            end
          end
        end
      else
        -- No entity under cursor; maybe the player doesn't know how to use the picker.
        -- p.print("Place cursor over an object before activating picker tool.")
      end
    end
  end
end)
