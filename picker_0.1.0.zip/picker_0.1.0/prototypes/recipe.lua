data:extend({
 {
    type = "recipe",
    name = "tool-picker",
    enabled = "true",
    ingredients = 
    {
      {"copper-plate", 1},
      {"iron-plate", 1}
    },
    result = "tool-picker"
  },
 {
    type = "recipe",
    name = "tool-picker-advanced",
    enabled = "true",
    ingredients = 
    {
      {"steel-plate", 2},
      {"advanced-circuit", 1},
    },
    result = "tool-picker-advanced"
  },
})