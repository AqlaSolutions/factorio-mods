data:extend({
 {
    type = "item",
    name = "tool-picker",
    icon = "__picker__/graphics/icon_picker.png",
    flags = {"goes-to-quickbar"},
    subgroup = "tool",
    stack_size= 50,
  },
 {
    type = "item",
    name = "tool-picker-advanced",
    icon = "__picker__/graphics/icon_picker_advanced.png",
    flags = {"goes-to-quickbar"},
    subgroup = "tool",
    stack_size= 50,
  },
})